WILDHAVEN ARENA — FULL VERSION
==============================

Thank you for your purchase!

HOW TO PLAY
1. Unzip this folder anywhere.
2. Open index.html in any modern browser (Chrome, Edge, Firefox, Safari).
   Works offline — no install, no account. Sound on for the full experience!
3. Catch a team of creatures across three zones, defeat the three crowned
   Guardians to become Arena Champion, then press Duel to trade Battle Codes
   with players anywhere in the world and fight their teams.
Your progress saves automatically.

LICENSE — PERSONAL USE
Play on any of your devices. Do not resell, redistribute, or re-upload the
game files anywhere, free or paid.

Problems with your download? Reply to your purchase receipt email.
