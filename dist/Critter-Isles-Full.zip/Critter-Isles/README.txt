CRITTER ISLES — FULL VERSION
============================

Thank you for your purchase!

HOW TO PLAY
1. Unzip this folder anywhere.
2. Open index.html in any modern browser (Chrome, Edge, Firefox, Safari).
   Works offline — no install, no account.
3. Move with WASD or arrow keys (on-screen buttons appear on touch devices).
   Get close to a wild critter and press SPACE to throw an orb.
   Walk into glowing orbs to restock. Catch all 8 species to win!
Your progress saves automatically in the browser.

LICENSE — PERSONAL USE
Play on any of your devices. Do not resell, redistribute, or re-upload the
game files anywhere, free or paid.

Problems with your download? Reply to your purchase receipt email.
