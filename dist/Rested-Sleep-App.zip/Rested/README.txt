RESTED — SLEEP TRACKER & SOUNDS (full version)
=============================================

Thank you for your purchase!

INSTALL IT LIKE AN APP
1. Unzip and put these files on any web host that serves HTTPS
   (GitHub Pages, Netlify and Cloudflare Pages all do this free), or open
   index.html directly for a quick look.
2. On the phone, open the page and:
   - iPhone/iPad (Safari): Share -> "Add to Home Screen"
   - Android (Chrome): menu -> "Install app" / "Add to Home screen"
   It then launches full screen like any other app and works offline.

HOW TO USE IT
- Set your alarm, pick a soundscape, tap "Start tracking".
- Put the phone screen-up on the mattress beside your pillow, or on a
  nightstand within about a metre, PLUGGED IN. Tracking needs the screen on;
  the display dims itself to near-black to save power.
- In the morning tap Stop (or Stop on the alarm) and your night is scored.
- Tag your mornings. After a couple of weeks the You tab tells you which
  habits actually move your sleep quality.

IMPORTANT — WHAT THIS CAN AND CANNOT DO
Rested estimates sleep from movement and sound picked up by the microphone.
That works well for when you fell asleep, how broken the night was and how
long you slept. Splitting light / deep / dream sleep is an ESTIMATE — real
staging needs brain activity (EEG), which no phone can see. Use the trends
over weeks, not any single night's percentages.

Rested is a wellness tool, not a medical device, and does not diagnose or
treat any condition. If you regularly sleep badly, snore heavily or stop
breathing in your sleep, please talk to a doctor.

PRIVACY
Audio is analysed on the device in real time and is never recorded, stored
or uploaded. Your nights live only in this browser's local storage. Use
You -> Export to back them up.

LICENSE — PERSONAL USE
Use on any of your own devices. Do not resell or redistribute the files.
