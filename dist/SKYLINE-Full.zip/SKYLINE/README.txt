SKYLINE — FULL VERSION
======================

Thank you for your purchase!

HOW TO PLAY
1. Unzip this folder anywhere.
2. Open index.html in any modern browser (Chrome, Edge, Firefox, Safari).
   Works offline — no install, no account. Sound on for the wind!
3. Hold SPACE to throw a light-rope at the best anchor ahead; release on the
   upswing to fly. A/D steer, W reels the rope for speed. Chain swings to
   build FLOW. Deliver the lantern through every ring, chase gold times,
   then trade Flight Codes with anyone on Earth and race their ghost.
Your progress saves automatically.

LICENSE — PERSONAL USE
Play on any of your devices. Do not resell, redistribute, or re-upload the
game files anywhere, free or paid.

Problems with your download? Reply to your purchase receipt email.
