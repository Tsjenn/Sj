WILDHAVEN CREATURES CLIPART PACK
=================================
Thank you for your purchase!

Inside: 13 transparent PNGs (10 creatures + 3 quote designs),
4500 x 4500 px. They drop cleanly onto any background in Canva,
Procreate, PowerPoint, Cricut Design Space or any editor.

Tip: for small prints (stickers, cards) just resize down — the
files are large so they stay sharp at any size you need.

See LICENSE.txt for what's allowed. Enjoy the critters!
