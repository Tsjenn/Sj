NEON DRIFT RACERS — FULL VERSION
================================

Thank you for your purchase!

HOW TO PLAY
1. Unzip this folder anywhere.
2. Open index.html in any modern browser (Chrome, Edge, Firefox, Safari).
   Works offline — no install, no account. Sound on for the full experience!
3. Build your driver in the Garage, pick a machine, and race.
   W / arrows to drive. Hold SHIFT through a corner to DRIFT — the longer the
   drift, the bigger the boost when you release. Chain drifts to win.
   SPACE fires nitro when the bar is full. R respawns you.
4. Set a lap time, then hit Online: your run becomes a RACE CODE. Send it to
   anyone on Earth and they race your ghost. Paste theirs to race them back.
Your progress, records and leaderboard save automatically.

LICENSE — PERSONAL USE
Play on any of your devices. Do not resell, redistribute, or re-upload the
game files anywhere, free or paid.

Problems with your download? Reply to your purchase receipt email.
