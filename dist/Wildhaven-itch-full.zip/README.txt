WILDHAVEN: CREATURE PARK — FULL VERSION
=======================================

Thank you for your purchase!

HOW TO PLAY
1. Unzip this folder anywhere.
2. Open index.html in any modern browser (Chrome, Edge, Firefox, Safari).
   Works offline — no install, no account. Sound on for the full experience!
3. Explore east into the wilds, catch creatures with SPACE, build habitats
   for them back in your park (Build menu), and welcome paying visitors.
   Grow your park to 5 stars and complete your collection to win.
Your progress saves automatically.

LICENSE — PERSONAL USE
Play on any of your devices. Do not resell, redistribute, or re-upload the
game files anywhere, free or paid.

Problems with your download? Reply to your purchase receipt email.
